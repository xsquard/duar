require('dotenv').config()
const { decryptMedia, Client } = require('@open-wa/wa-automate')
const moment = require('moment-timezone')
moment.tz.setDefault('Asia/Jakarta').locale('id')
const { downloader, cekResi, removebg, urlShortener, meme, translate, getLocationData } = require('../../lib')
const { msgFilter, color, processTime, isUrl } = require('../../utils')
const mentionList = require('../../utils/mention')
const { uploadImages } = require('../../utils/fetcher')
const fs = require('fs-extra')
const axios = require('axios')
const get = require('got')
const { fetchMeme } = require('../../lib/fetcher')
let ban = JSON.parse(fs.readFileSync('./lib/banned.json'))
const {artinama,
    quotes,
    weton,
    corona,
    alay,
    namaninjaku,
    liriklagu,
    quotemaker,
    yt,
    ytmp3,
    gd,
    jodoh,
    hilih,
    weather,
    neko,
    lolinime,
    wpnime,
} = require('../../lib/functions')

const { menuId, menuEn } = require('./text') // Indonesian & English menu

module.exports = msgHandler = async (client = new Client(), message) => {
    try {
        const { type, id, from, t, sender, isGroupMsg, chat, caption, isMedia, mimetype, quotedMsg, quotedMsgObj, mentionedJidList } = message
        let { body } = message
        const { name, formattedTitle } = chat
        let { pushname, verifiedName, formattedName } = sender
        pushname = pushname || verifiedName || formattedName // verifiedName is the name of someone who uses a business account
        const botNumber = await client.getHostNumber() + '@c.us'
        const groupId = isGroupMsg ? chat.groupMetadata.id : ''
        const groupAdmins = isGroupMsg ? await client.getGroupAdmins(groupId) : ''
        const groupMembers = isGroupMsg ? await client.getGroupMembersId(groupId) : ''
        const isGroupAdmins = groupAdmins.includes(sender.id) || false
        const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
        const isOwner = sender.id === '6281339201132@c.us'
        // Bot Prefix
        const prefix = '#'
        body = (type === 'chat' && body.startsWith(prefix)) ? body : ((type === 'image' && caption) && caption.startsWith(prefix)) ? caption : ''
        const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
        const arg = body.trim().substring(body.indexOf(' ') + 1)
        const args = body.trim().split(/ +/).slice(1)
        const isCmd = body.startsWith(prefix)
        const uaOverride = process.env.UserAgent
        const url = args.length !== 0 ? args[0] : ''
        

        // [BETA] Avoid Spam Message
        if (isCmd && msgFilter.isFiltered(from) && !isGroupMsg) { return console.log(color('[SPAM]', 'red'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname)) }
        if (isCmd && msgFilter.isFiltered(from) && isGroupMsg) { return console.log(color('[SPAM]', 'red'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname), 'in', color(name || formattedTitle)) }
        //
        if (!isCmd && !isGroupMsg) { return console.log('[RECV]', color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), 'Message from', color(pushname)) }
        if (!isCmd && isGroupMsg) { return console.log('[RECV]', color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), 'Message from', color(pushname), 'in', color(name || formattedTitle)) }
        if (isCmd && !isGroupMsg) { console.log(color('[EXEC]'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname)) }
        if (isCmd && isGroupMsg) { console.log(color('[EXEC]'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname), 'in', color(name || formattedTitle)) }

        // [BETA] Avoid Spam Message
        msgFilter.addFilter(from)

        switch (command) {
        // Menu and TnC
        case 'speed':
        case 'ping':
            const tetxt = `Halo, ${pushname}! 👋️ BOT AKTIF YA\nSpeed: ${processTime(moment())} _Second_`
            await client.sendText(from, tetxt)
            break
       // case 'tnc':
            //await client.sendText(from, menuId.textTnC())
            //break
            case 'help':
await client.sendText(from, menuId.helpMenu(pushname))
          break
        case 'fmenu':
await client.sendText(from, menuId.textfMenu(pushname))
break
          case 'menu':
            await client.sendText(from, menuId.textMenu(pushname))
            break
        case 'menuadmin':
            if (!isGroupMsg) return client.reply(from, 'Maaf, perintah ini hanya dapat dipakai didalam grup! [Group Only]', id)
            if (!isGroupAdmins) return client.reply(from, 'Gagal, perintah ini hanya dapat digunakan oleh admin grup! [Admin Group Only]', id)
            await client.sendText(from, menuId.textAdmin())
            break
       /* case 'donate':
        case 'donasi':
            await client.sendText(from, menuId.textDonasi())
            break*/
        // Sticker Creator
        case 'sticker':
        case 'stiker': {
            const isQuotedImage = quotedMsg && quotedMsg.type === 'image'
            if ((isMedia || isQuotedImage) && args.length === 0) {
                const encryptMedia = isQuotedImage ? quotedMsg : message
                const _mimetype = isQuotedImage ? quotedMsg.mimetype : mimetype
                const mediaData = await decryptMedia(encryptMedia, uaOverride)
                const imageBase64 = `data:${_mimetype};base64,${mediaData.toString('base64')}`
                client.sendImageAsSticker(from, imageBase64).then(() => {
                    console.log(`Sticker Processed for ${processTime(t, moment())} Second`)
                })
            } else if (args[0] === 'nobg') {
                 if (isMedia && type == 'image') {
                const mediaData = await decryptMedia(message, uaOverride)
                const imageBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
                const filename = "./media/pic.jpg";
                fs.writeFile(filename, mediaData, function (err) {
                    return console.log(err)
                })
                const base64img = fs.readFileSync(filename, { encoding: "base64" });
                //console.log(base64img)
                const outFile = './media/noBg.png'
                removeBackgroundFromImageBase64({
                    base64img,
                    apiKey: 'sfURa1LXZZ2xpeebeEY4xRUi',
                    size: 'auto',
                    type: 'auto',
                    outFile
                }).then(result => {
                    console.log(result)
                    fs.writeFile(outFile, result.base64img)
                    client.sendImageAsSticker(from, outFile)
                }).catch(err => {
                    console.log(err)
                })
            }
            } else if (args.length === 1) {
                if (!isUrl(url)) { await client.reply(from, 'Maaf, link yang kamu kirim tidak valid. [Invalid Link]', id) }
                client.sendStickerfromUrl(from, url).then((r) => (!r && r !== undefined)
                    ? client.sendText(from, 'Maaf, link yang kamu kirim tidak memuat gambar. [No Image]')
                    : ).then(() => console.log(`Sticker Processed for ${processTime(t, moment())} Second`))
            } else {
                await client.reply(from, 'Tidak ada gambar! Untuk membuka daftar perintah kirim #menu [Wrong Format]', id)
            }
            break
        }
        case 'stikerimage':
const isQuotedImage = quotedMsg && quotedMsg.type === 'image'
const mediaData = await decryptMedia(quotedMsg, uaOverride)
                const imageBase64 = `data:${quotedMsg.mimetype};base64,${mediaData.toString('base64')}`
                client.sendFileFromUrl(from, imageBase64, `test.jpg`, '', message.id)
                break
        case 'stikergif':
        case 'stickergif':
        case 'gifstiker':
        case 'gifsticker': {
            if (args.length !== 1) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            const isGiphy = url.match(new RegExp(/https?:\/\/(www\.)?giphy.com/, 'gi'))
            const isMediaGiphy = url.match(new RegExp(/https?:\/\/media.giphy.com\/media/, 'gi'))
            if (isGiphy) {
                const getGiphyCode = url.match(new RegExp(/(\/|\-)(?:.(?!(\/|\-)))+$/, 'gi'))
                if (!getGiphyCode) { return client.reply(from, 'Gagal mengambil kode giphy', id) }
                const giphyCode = getGiphyCode[0].replace(/[-\/]/gi, '')
                const smallGifUrl = 'https://media.giphy.com/media/' + giphyCode + '/giphy-downsized.gif'
                client.sendGiphyAsSticker(from, smallGifUrl).then(() => {
                    console.log(`Sticker Processed for ${processTime(t, moment())} Second`)
                }).catch((err) => console.log(err))
            } else if (isMediaGiphy) {
                const gifUrl = url.match(new RegExp(/(giphy|source).(gif|mp4)/, 'gi'))
                if (!gifUrl) { return client.reply(from, 'Gagal mengambil kode giphy', id) }
                const smallGifUrl = url.replace(gifUrl[0], 'giphy-downsized.gif')
                client.sendGiphyAsSticker(from, smallGifUrl).then(() => {
                    console.log(`Sticker Processed for ${processTime(t, moment())} Second`)
                }).catch((err) => console.log(err))
            } else {
                await client.reply(from, 'maaf, untuk saat ini sticker gif hanya bisa menggunakan link dari giphy.  [Giphy Only]', id)
            }
            break
        }
        // Video Downloader
        case 'tiktok':
            if (args.length !== 1) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            if (!isUrl(url) && !url.includes('tiktok.com')) return client.reply(from, 'Maaf, link yang kamu kirim tidak valid. [Invalid Link]', id)
            await client.reply(from, `_Scraping Metadata..._ \n\n${menuId.textDonasi()}`, id)
            downloader.tiktok(url).then(async (videoMeta) => {
                const filename = videoMeta.authorMeta.name + '.mp4'
                const caps = `*Metadata:*\nUsername: ${videoMeta.authorMeta.name} \nMusic: ${videoMeta.musicMeta.musicName} \nView: ${videoMeta.playCount.toLocaleString()} \nLike: ${videoMeta.diggCount.toLocaleString()} \nComment: ${videoMeta.commentCount.toLocaleString()} \nShare: ${videoMeta.shareCount.toLocaleString()} \nCaption: ${videoMeta.text.trim() ? videoMeta.text : '-'}`
                await client.sendFileFromUrl(from, videoMeta.url, filename, videoMeta.NoWaterMark ? caps : `⚠ Video tanpa watermark tidak tersedia. \n\n${caps}`, '', { headers: { 'User-Agent': 'okhttp/4.5.0', referer: 'https://www.tiktok.com/' } }, true)
                    .then((serialized) => console.log(`Sukses Mengirim File dengan id: ${serialized} diproses selama ${processTime(t, moment())}`))
                    .catch((err) => console.error(err))
            }).catch(() => client.reply(from, 'Gagal mengambil metadata, link yang kamu kirim tidak valid. [Invalid Link]', id))
            break
case 'ig':
        case 'instagram':
            if (args.length >= 1) {
                var param = body.substring(body.indexOf(' '), body.length)
                    //client.reply(from, 'Tunggu sebentar, sedang di proses..', message.id)
                    const resp = await get.get('https://villahollanda.com/api.php?url='+ param).json()
                    console.log(resp)
                    if (resp.mediatype == 'photo') {
                        var ext = '.png'
                    }else{
                        var ext = '.mp4'
                    }
                        client.sendFileFromUrl(from, resp.descriptionc, `igeh${ext}`, '', message.id)
                }
            break
        case 'ig2':
        case 'instagram2':
            if (args.length !== 1) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            if (!isUrl(url) && !url.includes('instagram.com')) return client.reply(from, 'Maaf, link yang kamu kirim tidak valid. [Invalid Link]', id)
            await client.reply(from, `_Scraping Metadata..._ \n\n${menuId.textDonasi()}`, id)
            downloader.insta(url).then(async (data) => {
                if (data.type == 'GraphSidecar') {
                    if (data.image.length != 0) {
                        data.image.map((x) => client.sendFileFromUrl(from, x, 'photo.jpg', '', null, null, true))
                            .then((serialized) => console.log(`Sukses Mengirim File dengan id: ${serialized} diproses selama ${processTime(t, moment())}`))
                            .catch((err) => console.error(err))
                    }
                    if (data.video.length != 0) {
                        data.video.map((x) => client.sendFileFromUrl(from, x.videoUrl, 'video.jpg', '', null, null, true))
                            .then((serialized) => console.log(`Sukses Mengirim File dengan id: ${serialized} diproses selama ${processTime(t, moment())}`))
                            .catch((err) => console.error(err))
                    }
                } else if (data.type == 'GraphImage') {
                    client.sendFileFromUrl(from, data.image, 'photo.jpg', '', null, null, true)
                        .then((serialized) => console.log(`Sukses Mengirim File dengan id: ${serialized} diproses selama ${processTime(t, moment())}`))
                        .catch((err) => console.error(err))
                } else if (data.type == 'GraphVideo') {
                    client.sendFileFromUrl(from, data.video.videoUrl, 'video.mp4', '', null, null, true)
                        .then((serialized) => console.log(`Sukses Mengirim File dengan id: ${serialized} diproses selama ${processTime(t, moment())}`))
                        .catch((err) => console.error(err))
                }
            })
                .catch((err) => {
                    if (err === 'Not a video') { return client.reply(from, 'Error, tidak ada video di link yang kamu kirim. [Invalid Link]', id) }
                    client.reply(from, 'Error, user private atau link salah [Private or Invalid Link]', id)
                })
            break
        case 'twt':
        case 'twitter':
            if (args.length !== 1) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            if (!isUrl(url) & !url.includes('twitter.com') || url.includes('t.co')) return client.reply(from, 'Maaf, url yang kamu kirim tidak valid. [Invalid Link]', id)
            await client.reply(from, `_Scraping Metadata..._ \n\n${menuId.textDonasi()}`, id)
            downloader.tweet(url).then(async (data) => {
                if (data.type === 'video') {
                    const content = data.variants.filter(x => x.content_type !== 'application/x-mpegURL').sort((a, b) => b.bitrate - a.bitrate)
                    const result = await urlShortener(content[0].url)
                    console.log('Shortlink: ' + result)
                    await client.sendFileFromUrl(from, content[0].url, 'video.mp4', null, null, true)
                        .then((serialized) => console.log(`Sukses Mengirim File dengan id: ${serialized} diproses selama ${processTime(t, moment())}`))
                        .catch((err) => console.error(err))
                } else if (data.type === 'photo') {
                    for (let i = 0; i < data.variants.length; i++) {
                        await client.sendFileFromUrl(from, data.variants[i], data.variants[i].split('/media/')[1], '', null, null, true)
                            .then((serialized) => console.log(`Sukses Mengirim File dengan id: ${serialized} diproses selama ${processTime(t, moment())}`))
                            .catch((err) => console.error(err))
                    }
                }
            })
                .catch(() => client.sendText(from, 'Maaf, link tidak valid atau tidak ada media di link yang kamu kirim. [Invalid Link]'))
            break
        case 'fb':
        case 'facebook':
            if (args.length !== 1) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            if (!isUrl(url) && !url.includes('facebook.com')) return client.reply(from, 'Maaf, url yang kamu kirim tidak valid. [Invalid Link]', id)
            //await client.reply(from, '_Scraping Metadata..._ \n\nTerimakasih telah menggunakan bot ini, kamu dapat membantu pengembangan bot ini dengan menyawer melalui https://saweria.co/donate/yogasakti atau mentrakteer melalui https://trakteer.id/red-emperor \nTerimakasih.', id)
            downloader.facebook(url).then(async (videoMeta) => {
                const title = videoMeta.response.title
                const thumbnail = videoMeta.response.thumbnail
                const links = videoMeta.response.links
                const shorts = []
                for (let i = 0; i < links.length; i++) {
                    const shortener = await urlShortener(links[i].url)
                    console.log('Shortlink: ' + shortener)
                    links[i].short = shortener
                    shorts.push(links[i])
                    await client.sendFileFromUrl(from, links[i].url, 'videos.mp4')
                }
                const link = shorts.map((x) => `${x.resolution} Quality: ${x.short}`)
                const caption = `Text: ${title} \n\nLink Download: \n${link.join('\n')} \n\nProcessed for ${processTime(t, moment())} _Second_`
                
                    .then((serialized) => console.log(`Sukses Mengirim File dengan id: ${serialized} diproses selama ${processTime(t, moment())}`))
                    .catch((err) => console.error(err))
            })
            break
        // Other Command
        case 'memec':
const isQuotedImage = quotedMsg && quotedMsg.type === 'image'
            if ((isMedia || isQuotedImage) && args.length >= 2) {
                const top = arg.split('|')[0]
                const bottom = arg.split('|')[1]
                const encryptMedia = isQuotedImage ? quotedMsg : message
                const mediaData = await decryptMedia(encryptMedia, uaOverride)
                const getUrl = await uploadImages(mediaData, false)
                const ImageBase64 = await meme.custom(getUrl, top, bottom)
                client.sendFile(from, ImageBase64, 'image.png', '', null, true)
                    .then((serialized) => console.log(`Sukses Mengirim File dengan id: ${serialized} diproses selama ${processTime(t, moment())}`))
                    .catch((err) => console.error(err))
            } else {
                await client.reply(from, 'Tidak ada gambar! Untuk membuka cara penggnaan kirim #menu [Wrong Format]', id)
            }
            break
        case 'resi':
            if (args.length !== 2) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            const kurirs = ['jne', 'pos', 'tiki', 'wahana', 'jnt', 'rpx', 'sap', 'sicepat', 'pcp', 'jet', 'dse', 'first', 'ninja', 'lion', 'idl', 'rex']
            if (!kurirs.includes(args[0])) return client.sendText(from, `Maaf, jenis ekspedisi pengiriman tidak didukung layanan ini hanya mendukung ekspedisi pengiriman ${kurirs.join(', ')} Tolong periksa kembali.`)
            console.log('Memeriksa No Resi', args[1], 'dengan ekspedisi', args[0])
            cekResi(args[0], args[1]).then((result) => client.sendText(from, result))
            break
        case 'translate':
            if (args.length != 1) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            if (!quotedMsg) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            const quoteText = quotedMsg.type == 'chat' ? quotedMsg.body : quotedMsg.type == 'image' ? quotedMsg.caption : ''
            translate(quoteText, args[0])
                .then((result) => client.sendText(from, result))
                .catch(() => client.sendText(from, 'Error, Kode bahasa salah.'))
            break
        case 'ceklokasi':
            if (quotedMsg.type !== 'location') return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            console.log(`Request Status Zona Penyebaran Covid-19 (${quotedMsg.lat}, ${quotedMsg.lng}).`)
            const zoneStatus = await getLocationData(quotedMsg.lat, quotedMsg.lng)
            if (zoneStatus.kode !== 200) client.sendText(from, 'Maaf, Terjadi error ketika memeriksa lokasi yang anda kirim.')
            let data = ''
            for (let i = 0; i < zoneStatus.data.length; i++) {
                const { zone, region } = zoneStatus.data[i]
                const _zone = zone == 'green' ? 'Hijau* (Aman) \n' : zone == 'yellow' ? 'Kuning* (Waspada) \n' : 'Merah* (Bahaya) \n'
                data += `${i + 1}. Kel. *${region}* Berstatus *Zona ${_zone}`
            }
            const text = `*CEK LOKASI PENYEBARAN COVID-19*\nHasil pemeriksaan dari lokasi yang anda kirim adalah *${zoneStatus.status}* ${zoneStatus.optional}\n\nInformasi lokasi terdampak disekitar anda:\n${data}`
            client.sendText(from, text)
            break
//tambahan
case 'tts':
            if (args.length == 0) return client.reply(from, 'Kirim perintah *!tts* [id, en, jp, ar] <teks>, contoh *!tts* id halo semua')
            const ttsId = require('node-gtts')('id')
                const ttsEn = require('node-gtts')('en')
            const ttsJp = require('node-gtts')('ja')
                const ttsAr = require('node-gtts')('ar')
                const dataText = body.slice(8)
                var dataBhs = body.slice(5, 7)
            if (dataBhs == 'id') {
                    ttsId.save('./tts/resId.mp3', dataText, function () {
                        client.sendPtt(from, './tts/resId.mp3', message.id)
                })
        } else if (dataBhs == 'en') {
                    ttsEn.save('./tts/resEn.mp3', dataText, function () {
                        client.sendPtt(from, './tts/resEn.mp3', message.id)
                })
        } else if (dataBhs == 'jp') {
                    ttsJp.save('./tts/resJp.mp3', dataText, function () {
                        client.sendPtt(from, './tts/resJp.mp3', message.id)
                })
        } else if (dataBhs == 'ar') {
                    ttsAr.save('./tts/resAr.mp3', dataText, function () {
                        client.sendPtt(from, './tts/resAr.mp3', message.id)
                })
        } else {
            client.reply(from, 'Masukkan data bahasa : [id] untuk indonesia, [en] untuk inggris, [jp] untuk jepang, dan [ar] untuk arab', message.id)
            }
            break
    case 'unsplash':
                        client.sendFileFromUrl(from, 'https://source.unsplash.com/daily', 'wallpaper.png'); // UwU)/ Working Fine
                    break;
                case 'kuching':
                    q2 = Math.floor(Math.random() * 900) + 300;
                    q3 = Math.floor(Math.random() * 900) + 300;
                    client.sendFileFromUrl(from, 'http://placekitten.com/'+q3+'/'+q2, 'kuching.png');
                    break
                case 'anime' :
                       q4 = Math.floor(Math.random() * 800) + 100;
                    client.sendFileFromUrl(from, 'https://wallpaperaccess.com/download/anime-'+q4,'Anime.png');
                    break
                case 'wp':
                    if (args.length >=2) {
                    const keyword = args[1]
                    client.sendFileFromUrl(from, 'https://source.unsplash.com/1600x900/?'+args[1],'wp.jpeg')    
                    };
                    break
             case 'lasegar':
                   q2 = Math.floor(Math.random() * 10) + 1;
                   client.sendFileFromUrl(from, 'https://lines.masgimenz.com/gambar/'+q2+'.jpg','halo.jpg');
                  break
 case 'corona':    
                         const response = await axios.get('https://coronavirus-19-api.herokuapp.com/countries/Indonesia/');
                         const { cases, todayCases, deaths, todayDeaths, recovered, active } = response.data
                         await client.sendText(from, 'Kasus *Indonesia* 🇮🇩\n\n✨️Total Kasus: '+`${cases}`+'\n📆️Kasus Hari Ini: '+`${todayCases}`+'\n☣️Meningal : '+`${deaths}`+'\n😊 Sembuh : '+`${recovered}`+'\n⛩️Kasus Aktif : '+`${active}`+'.')

                break
case 'artinama':
                    if (args.length >= 1) {
                        const nama = args[1]
                         const result = await liriklagu(nama)
                        client.sendText(from, result)
                    }
                    break
                case 'liriklagu':
                    if (args.length >= 1){
                        const lagu = arg.split('|')[0]
                        const result = await liriklagu(lagu)
                        client.sendText(from, result)
                    }
                    break
                case 'weton':
                    if (args.length >= 3) {
                        const tgl = args[1]
                        const bln = args[2]
                        const thn = args[3]
                        const result = await weton(tgl, bln, thn)
                        client.sendText(from, result)
                    }
                    break;
                case 'alay':
                    if (args.length >= 1) {
                       const kata = arg.split('|')[0]
                       const result = await alay(kata)
                     client.sendText(from, result)
                    }
                    break
                case 'namaninjaku':
                    if (args.length >= 1) {
                        const nama = args[1]
                        const result = await namaninjaku(nama)
                        client.sendText(from, result)
                    }
                    break
                    case 'quotesmaker' :
                case 'quotemaker':
                    await client.simulateTyping(from, true)
                    //client.sendText(from, '⏳ Tunggu yaa, sedang proses . . . ⏳')                
                    if (args.length >= 3) {
                        const quotes = args[1]
                        const author = args[2]
                        const theme = args[3]
                        const result = await quotemaker(quotes, author, theme)
                        client.sendFile(from, result, 'quotesmaker.jpg')
                    }
                    break;
                    case 'quote2make':
                    //await client.simulateTyping(from, true)
                    //client.sendText(from, '⏳ Tunggu yaa, sedang proses . . . ⏳')
                        client.sendFileFromUrl(from, 'https://terhambar.com/aw/qts/proses.php?kata='+args[1]+'&author='+args[2]+'&tipe='+args[3]+'&font=./font/font3.otf&size='+args[4],'quote.jpg');
                    break
                case 'yt':
                   // await client.simulateTyping(from, true)
                    //client.sendText(from, '⏳ Tunggu yaa, sedang proses . . . ⏳')
                    if (args.length >=1){
                        const result = await yt(url)
                        client.sendFileFromUrl(from, result , 'video.mp4')
                    }
                    break 
                case 'ytmp3':
                   // await client.simulateTyping(from, true)
                    //client.sendText(from, '⏳ Tunggu yaa, sedang proses . . . ⏳')
if (args.length >= 1) {
                var paramex = body.substring(body.indexOf(' '), body.length)
                    //client.reply(from, 'Tunggu sebentar, sedang di proses..', message.id)
                    const respe = await get.get('http://scrap.terhambar.com/yt?link='+ paramex).json()
                    console.log(respe)
                    
                        client.sendFileFromUrl(from, resp.descriptionc, `audio.mp3`, '', message.id)
                }
                    break                  
                case 'gd':
                    if (args.length >=1){
                        const url = args[1]
                        const result = await gd(url)
                        client.sendText(from, result)
                    }
                    break  
                case 'jodoh':
                    if (args.length >= 2) {
                        const nama1 = args[1]
                        const nama2 = args[2]
                        const result = await jodoh(nama1, nama2)
                        client.sendText(from, result)
                    }
                    break   
                case 'hilih':
                    if (args.length >=1){
                        const kata = arg.split('|')[0]
                        const result = await hilih(kata)
                        client.sendText(from, result)
                    }
                    break  
                  case 'cuaca':  
                case 'weather':
                    if (args.length >=1){
                        const kota = args[1]
                        const result = await weather(kota)
                        client.sendText(from, result)
                    }
                    break  

                      case 'neko':    
                        const wpo = await neko()
                        client.sendFileFromUrl(from, wpo, 'wponimex.jpg')
                        
                break      
                case 'wpnime':    
                        const wpn = await wpnime()
                        client.sendFileFromUrl(from, wpn, 'wpnimex.jpg')
                        
                break   
                
                case 'lolinime':    
                        const wpl = await lolinime()
                        client.sendFileFromUrl(from, wpl, 'wplonimex.jpg')
                        
                break   
                case 'waifu':    
                        q8 = q2 = Math.floor(Math.random() * 98) + 10;
                        client.sendFileFromUrl(from, 'http://randomwaifu.altervista.org/images/00'+q8+'.png', 'Waifu.png'); // UwU)/ Working Fine
                    break
case 'surah':
                                if(!args.lenght >= 3) return
                                const dictzk = body.split(' ')[1];
                                const ayat = body.split(' ')[3];
                                if (!isNaN(dictzk) && dictzk <= 114) {
                                    if (ayat !== undefined) {
                                        axios.get(`https://api.banghasan.com/quran/format/json/surat/${dictzk}/ayat/${ayat}`).then((res) => {
                                            if (isNullOrUndefined(res.data.ayat.error) === true) {
                                                let hasil = `Surah ${res.data.surat.nama} ayat ${ayat} : \n\n`;
                                                let indexs = res.data.ayat.data.ar;
                                                let a = res.data.ayat.data.idt;
                                                let b = res.data.ayat.data.id;
                                                Object.keys(indexs).forEach(function (i) {
                                                    hasil += `[${indexs[i].ayat}]  ${indexs[i].teks}\n`;
                                                    hasil += `\n${striptags(a[i].teks)}\n`;
                                                    hasil += `\nArtinya : ${curlyRemover(b[i].teks)}\n`;
                                                })
                                                client.sendText(from,hasil);
                                            } else {
                                                client.sendText(from,`Error, ayat ${ayat} surah ${dictzk} tidak valid`);
                                            }
                                        })
                                    } else {
                                        axios.get(`https://api.banghasan.com/quran/format/json/surat/${dictzk}`).then((res) => {
                                            const sr = /<(.*?)>/gi;
                                            const hs = res.data.hasil[0];
                                            const ket = `${hs.keterangan}`.replace(sr, '');
                                            client.sendText(from,`╭───[ Hasil Surah ]───\n├ Nomor Surah : ${hs.nomor}\n├ Nama Surah : ${hs.nama}\n├ Asma Surah : ${hs.asma}\n├ Jumlah Ayat : ${hs.ayat}\n├ Tipe Surah : ${hs.type}\n├ Urut : ${hs.urut}\n├ Rukuk Surah : ${hs.rukuk}\n├ Arti Surah : ${hs.arti}\n╰──[ Surah ${hs.nama} ]───\n\n${ket}`);
                                        })
                                    }
                                } else {
                                    client.sendText(from,`Error, nomor surah ${dictzk} tidak valid\n #list surah* ~> menampilkan list surah`);
                                }
                            break
case 'mim':
        case 'memes':
        case 'meme':
            meme().then(({ title, url }) => client.sendFileFromUrl(from, `${url}`, 'meme.jpg', `${title}`, null, null, true))
            break
case 'igstalk':
                        if(!args.lenght >= 2) return
                        if(!args[1]) return
                        let usrname = args[1]
                        if (usrname.includes('@')) {
                            usrname = usrname.replace('@', '');
                        }
                        const browser = await puppeteer.launch({
                            headless: true,
                            args: [
                                "--no-sandbox",
                                "--disable-setuid-sandbox",
                                "--disable-dev-shm-usage",
                                "--disable-accelerated-2d-canvas",
                                "--disable-gpu",
                                "--window-size=1920x1080",
                            ],
                            });
                            const page = await browser.newPage();
                            await page.setRequestInterception(true);
                            page.on('request', request => {
                            if (request.resourceType() === 'image' || request.resourceType() === 'stylesheet')
                                request.abort();
                            else
                                request.continue();
                            });
                            await page
                            .goto(`https://www.mystalk.net/profile/${usrname}/`,{
                                waitUntil: "networkidle2",
                            })
                            .then(async () => {
                            page.setViewport({ width: 420, height: 840 , deviceScaleFactor:2});
                            const post = await (await (await page.$('#section-main > div.user-profile-area > div > div > div.col-md-5 > div > span:nth-child(1) > b')).getProperty('innerHTML')).jsonValue();
                            let prvate;
                            const username = await (await (await page.$('#section-main > div.user-profile-area > div > div > div.col-md-7 > div > div > div > h1 > span.user-name')).getProperty('innerHTML')).jsonValue();
                            const full_name = await (await (await page.$('#section-main > div.user-profile-area > div > div > div.col-md-7 > div > div > div > h1 > span.name')).getProperty('innerHTML')).jsonValue();
                            const biography = await (await (await page.$('#section-main > div.user-profile-area > div > div > div.col-md-7 > div > div > p')).getProperty('innerHTML')).jsonValue();
                            if(await page.$('#section-main > div.private-warning > div > span') !== null) prvate = true;
                            else prvate = false;
                            const followers = await (await (await page.$('#section-main > div.user-profile-area > div > div > div.col-md-5 > div > span:nth-child(2) > b')).getProperty('innerHTML')).jsonValue();
                            const followed = await (await (await page.$('#section-main > div.user-profile-area > div > div > div.col-md-5 > div > span:nth-child(3) > b')).getProperty('innerHTML')).jsonValue();
                            if (prvate === true) {
                                prvate = 'Iya';
                            } else {
                                prvate = 'Tidak';
                            }
                            let hasil = `_*Instagram Stalker*_
=> Username : ${username}
=> Nama : ${full_name}
=> Jumlah post : ${post}
=> Followed : ${followed} followed
=> Followers : ${followers} followers
=> Bio :
-------------------------------------------------------------------
${biography}
-------------------------------------------------------------------`
                            client.sendText(from, hasil);
                            browser.close();
                            }).catch((err) => {
                                console.log(err)
                                client.sendText(from,`[GAGAL] Username tidak ditemukan!`
                            );
                            browser.close();
                            });
                    break
case 'qrcode':
                        if(!args.lenght >= 2) return
                        let qrcodes = body.slice(8)
                        await client.sendFileFromUrl(from, `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${qrcodes}`, 'gambar.png', '_*Processing Sukses #XyZ BOT*_').catch(err => console.log('[ERROR] send image'))
break
        // Group Commands (group admin only)
        case 'kick':
            if (!isGroupMsg) return client.reply(from, 'Maaf, perintah ini hanya dapat dipakai didalam grup! [Group Only]', id)
            if (!isGroupAdmins) return client.reply(from, 'Gagal, perintah ini hanya dapat digunakan oleh admin grup! [Admin Group Only]', id)
            if (!isBotGroupAdmins) return client.reply(from, 'Gagal, silahkan tambahkan bot sebagai admin grup! [Bot Not Admin]', id)
            if (mentionedJidList.length === 0) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            if (mentionedJidList[0] === botNumber) return await client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            await client.sendTextWithMentions(from, `Request diterima, mengeluarkan:\n${mentionedJidList.map(x => `@${x.replace('@c.us', '')}`).join('\n')}`)
            for (let i = 0; i < mentionedJidList.length; i++) {
                if (groupAdmins.includes(mentionedJidList[i])) return await client.sendText(from, 'Gagal, kamu tidak bisa mengeluarkan admin grup.')
                await client.removeParticipant(groupId, mentionedJidList[i])
            }
            break
        case 'promote':
            if (!isGroupMsg) return await client.reply(from, 'Maaf, perintah ini hanya dapat dipakai didalam grup! [Group Only]', id)
            if (!isGroupAdmins) return await client.reply(from, 'Gagal, perintah ini hanya dapat digunakan oleh admin grup! [Admin Group Only]', id)
            if (!isBotGroupAdmins) return await client.reply(from, 'Gagal, silahkan tambahkan bot sebagai admin grup! [Bot not Admin]', id)
            if (mentionedJidList.length != 1) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format, Only 1 user]', id)
            if (groupAdmins.includes(mentionedJidList[0])) return await client.reply(from, 'Maaf, user tersebut sudah menjadi admin. [Bot is Admin]', id)
            if (mentionedJidList[0] === botNumber) return await client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            await client.promoteParticipant(groupId, mentionedJidList[0])
            await client.sendTextWithMentions(from, `Request diterima, menambahkan @${mentionedJidList[0].replace('@c.us', '')} sebagai admin.`)
            break
        case 'demote':
            if (!isGroupMsg) return client.reply(from, 'Maaf, perintah ini hanya dapat dipakai didalam grup! [Group Only]', id)
            if (!isGroupAdmins) return client.reply(from, 'Gagal, perintah ini hanya dapat digunakan oleh admin grup! [Admin Group Only]', id)
            if (!isBotGroupAdmins) return client.reply(from, 'Gagal, silahkan tambahkan bot sebagai admin grup! [Bot not Admin]', id)
            if (mentionedJidList.length !== 1) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format, Only 1 user]', id)
            if (!groupAdmins.includes(mentionedJidList[0])) return await client.reply(from, 'Maaf, user tersebut tidak menjadi admin. [user not Admin]', id)
            if (mentionedJidList[0] === botNumber) return await client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            await client.demoteParticipant(groupId, mentionedJidList[0])
            await client.sendTextWithMentions(from, `Request diterima, menghapus jabatan @${mentionedJidList[0].replace('@c.us', '')}.`)
            break
        case 'bye':
            if (!isGroupMsg) return client.reply(from, 'Maaf, perintah ini hanya dapat dipakai didalam grup! [Group Only]', id)
            if (!isGroupAdmins) return client.reply(from, 'Gagal, perintah ini hanya dapat digunakan oleh admin grup! [Admin Group Only]', id)
            client.sendText(from, 'Good bye... ( ⇀‸↼‶ )').then(() => client.leaveGroup(groupId))
            break
        case 'del':
            if (!isGroupAdmins) return client.reply(from, 'Gagal, perintah ini hanya dapat digunakan oleh admin grup! [Admin Group Only]', id)
            if (!quotedMsg) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            if (!quotedMsgObj.fromMe) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            client.deleteMessage(quotedMsgObj.chatId, quotedMsgObj.id, false)
            break

        case 'tagall':
        case 'everyone':
            case 'mentionall':
            if (!isGroupMsg) return client.reply(from, 'Perintah ini hanya bisa di gunakan dalam group!',message.id)
            const groupMem = await client.getGroupMembers(groupId)
            let hehe = arg.split('|')[0]
            hehe += '\n'
            for (let i = 0; i < groupMem.length; i++) {
                hehe += ' '
                hehe += ` @${groupMem[i].id.replace(/@c.us/g, '')}`
            }
            client.sendTextWithMentions(from, hehe)
            break
             case 'bc':
            if(!isOwner) return client.reply(from, 'Perintah ini hanya untuk Owner bot!', message.id)
            let msg = body.slice(4)
            const chatz = await client.getAllChatIds()
            for (let ids of chatz) {
                var cvk = await client.getChatById(ids)
                if (!cvk.isReadOnly) client.sendText(ids, `\n${msg}`)
            }
            client.reply(from, 'Broadcast Success!', message.id)
            break
        case 'ban':
            if(!isOwner) return client.reply(from, 'Perintah *!ban* hanya untuk Owner bot!', message.id)
            for (let i = 0; i < mentionedJidList.length; i++) {
                ban.push(mentionedJidList[i])
                fs.writeFileSync('./lib/banned.json', JSON.stringify(ban))
                client.reply(from, 'Succes ban target!', message.id)
            }
            case 'clearall':
            if (!isOwner) return client.reply(from, 'Perintah ini hanya untuk Owner bot', message.id)
            const allChatz = await client.getAllChats()
            for (let dchat of allChatz) {
                await client.deleteChat(dchat.id)
            }
            client.reply(from, 'Succes clear all chat!', message.id)
            break
        case 'unban':
            if(!isOwner) return client.reply(from, 'Perintah *!unban* hanya untuk owner bot!', message.id)
            let inx = ban.indexOf(mentionedJidList[0])
            ban.splice(inx, 1)
            fs.writeFileSync('./lib/banned.json', JSON.stringify(ban))
            client.reply(from, 'Succes unban target!', message.id)
            break
           case 'linkgrup':
            if(isGroupMsg && isBotGroupAdmins && isGroupAdmins) {
                await client.revokeGroupInviteLink(groupId)
            } else if(!isGroupMsg) {
                client.reply(from, 'Fitur ini hanya bisa di gunakan dalam group', message.id)
            } else if(!isGroupAdmins) {
                client.reply(from, 'Fitur ini hanya bisa di gunakan oleh admin group', message.id)
            } else if(!isBotGroupAdmins) {
                client.reply(from, 'Fitur ini hanya bisa di gunakan ketika bot menjadi admin', message.id)
            }
            break
        case 'botstat': {
            const loadedMsg = await client.getAmountOfLoadedMessages()
            const chatIds = await client.getAllChatIds()
            const groups = await client.getAllGroups()
            client.sendText(from, `Status :\n- *${loadedMsg}* Loaded Messages\n- *${groups.length}* Group Chats\n- *${chatIds.length - groups.length}* Personal Chats\n- *${chatIds.length}* Total Chats`)
            break
        }
        default:
            console.log(color('[ERROR]', 'red'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), 'Unregistered Command from', color(pushname))
            break
        }
    } catch (err) {
        console.log(color('[ERROR]', 'red'), err)
    }
}
