exports.textTnC = () => {
    return `
Source code / bot ini merupakan program open-source (gratis) yang ditulis menggunakan Javascript, kamu dapat menggunakan, menyalin, memodifikasi, menggabungkan, menerbitkan, mendistribusikan, mensublisensikan, dan atau menjual salinan dengan tanpa menghapus author utama dari source code / bot ini.

Dengan menggunakan source code / bot ini maka anda setuju dengan Syarat dan Kondisi sebagai berikut:
- Source code / bot tidak menyimpan data anda di server kami.
- Source code / bot tidak bertanggung jawab atas sticker yang anda buat dari bot ini serta video, gambar maupun data lainnya yang anda dapatkan dari Source code / bot ini.
- Source code / bot tidak boleh digunakan untuk layanan yang bertujuan/berkontribusi dalam: 
    • seks / perdagangan manusia
    • perjudian
    • perilaku adiktif yang merugikan 
    • kejahatan
    • kekerasan (kecuali jika diperlukan untuk melindungi keselamatan publik)
    • pembakaran hutan / penggundulan hutan
    • ujaran kebencian atau diskriminasi berdasarkan usia, jenis kelamin, identitas gender, ras, seksualitas, agama, kebangsaan

Source Code BOT : https://github.com/YogaSakti/imageToSticker
NodeJS WhatsApp library: https://github.com/open-wa/wa-automate-nodejs

Best regards, Yoga Sakti.`
}
exports.helpMenu = (pushname) => {
     return `
Hi, ${pushname}! 👋️ 
Welcome To D-Bot!✨ 
https://d-bot.me

Bot Baru di hidupkan lagi....
Owner Kemarin Lagi Mager Soalnya...
Bot ini gratis untuk anda. Boleh reshare kalo suka.
Bot Ini pake Second Wa, Jadi pesan anda tidak akan dibaca & notifikasi sudah dihide
Bot Aktif mulai jam 07.00-22.00. kalo gak on jangan di spam.

*IG masih belum bisa ya*

Untuk list Command :
1. #ping : Untuk Mengecek Bot aktif atau ngaknya
2. #menu : untuk menampilkan command menu simple
3. #menuadmin : Menu khusus untuk admin di dalam grup
4. #join link_grup : untuk memasukan bot ke dalam grup (kalo gak join add manual ya)
5. #pesan isi pesan : untuk mengirim pesan ke owner bot (coming soon)

DILARANG KERAS UNTUK MENELFON BOT. TELFON = BLOCK!!
     `}
exports.textMenu = (pushname) => {
    return `
Hi, ${pushname}! 👋️

Tolong dilihat Formatnya Ya!! 

Ini Menunya :

======>Sticker Menu<=======

1. *#sticker*
Untuk merubah gambar menjadi sticker. (kirim gambar dengan caption #sticker atau balas gambar yang sudah dikirim dengan #sticker)

2. *#sticker* _<Url Gambar>_
Untuk merubah gambar dari url menjadi sticker. 

3. *#gifsticker* _<Giphy URL>_ / *#stickergif* _<Giphy URL>_
Untuk merubah gif menjadi sticker (Giphy Only)

======>Sosmed & Youtube<=======

1. *#ig* _<IG URL>_ / *#instagram* _<IG URL>
Untuk Mendownload video atau foto dari IG

2. *#ig2* _<IG URL>_ / *#instagram* _<IG URL>
Versi Ke 2 dari ig downloader

3. *#fb* _<Facebook URL>_ / *#facebook* _<Facebook URL>
Untuk Mendownload video dari Facebook

4. *#twt* _<Twitter URL>_ / *#twitter* _<Twitter URL>
Untuk Mendownload video atau foto dari Twitter

5. *#tiktok* _<Tiktok URL>_
Untuk Mendownload video dari tiktok

6. *#yt* _<Youtube URL>_ (masih eror)
Untuk Mendownload video dari youtube

7. *#ytmp3* _<Youtube URL>_ (masih eror)
Untuk Mendownload music dari youtube berbentuk mp3

======>Kejawen<=======

1. *#jodoh* _Namamu Namanya_
Untuk Menampilkan Ramalan jodoh

2. *#weton* _12 12 2000_
Untuk mengecek weton dan watak dari tanggal kelahiranmu

3. coming soon

======>Al-quran<=======

1. *#randayat*
menampilkan ayat alquran random

2. *#surah* (belum fix)
menampilkan surah dari alquran

3. *#jadwalshalat nama daerah*
menampilkan jadwal shalat

4. next update

======>Menu Lain<=======

1. *#hilih* _kata kata mu|-_
Untuk mengubah text jadi kiti kiti mi

2. *#corona*
Untuk Menampilkan data corona terbaru di Indonesia

3. *#artinama* _Namamu_
Untuk Menampilkan arti dari Namamu

4. *#liriklagu* _kata kata mu|-_
Untuk Mencari lirik lagu

5. *#translate* _kode negara(id/en)""
reply pesan dan translate ke bahasa lainnya

6. *#alay* _kata kata mu|-_
Untuk mengubah text jadi 4l4y

7. *#namaninjaku* _Namamu_
Untuk Menampilkan arti dari Nama ninjamu

8. *#quotesmaker* _kata-kata author background_
Untuk menampilkan gambar quotes bikinanmu

9. *#quote2make* _kata-kata author background ukurantext_
versi kedua dari #quotesmaker

10. *#cuaca* _kota_
Untuk menampilkan info cuaca kotamu

11. *#resi* _ekpedisi nomer_resi_
menampilkan info dari paket kamu

12. *#tts* _kata terserah kamu_
membuat vn dari kata terserah kamu (teks to speak)

13. *#toxic*
buat kirim pesan toxic

14. *#ceklokasi*_
kirim lokasi dan reply dengan hastaq untuk lihat status zona disekitarmu

15. *#tagall* _kata kata mu|-_
untuk tag semua anggota didalam grup

16. *#jam*
untuk menampilkan waktu sekarang di Indonesia

17. *#reverse* kata-katamu
Membalik-balikan kata-katamu

18. *#qrcode* nomer/kata
buat gambar qr code

======>Walpapper & Anime<=======

1. *#unsplash* / *#wp*
Menampilkan wallpaper dari unsplash

2. *#neko*
Menampilkan wallpaper dari anime cosplay kucing

3. *#wpnime*
Menampilkan wallpaper anime

4 *#lolinime*
Menampilkan wallpaper dari anime loli

5. *#waifu*
Menampilkan wallpaper waifu di anime

6. *#kuching*
Menampilkan wallpaper kucing

7. *#anjing*
Menampilkan gambar anjing

8. *#lasegar*
Menampilkan foto penyegar

    `}

exports.textAdmin = () => {
    return `
⚠ [ *Admin Group Only* ] ⚠ 
Berikut adalah beberapa fitur admin grup yang ada pada bot ini!

1. *#kick* @user
Untuk mengeluarkan member dari grup (bisa lebih dari 1).

2. *#promote* @user
Untuk mempromosikan member menjadi Admin grup.

3. *#demote* @user
Untuk demosikan Admin grup.

4. *#tagall*
Untuk mention semua member grup.

5. *#del*
Untuk menghapus pesan bot (balas pesan bot dengan #del)

6. *#bye*
Untuk mengeluarkan bot dari grup

7. *#linkgrup*
Untuk menampilkan link dari grup

8. *#bc*
Untuk Membroadcast ke anggota grup 

9. *#ownergroup*
menampilkan owner/pembuat grup ini

10. *#adminlist*
menampilkan list admin grup ini
`}

exports.textDonasi = () => {
    return `
Hai, terimakasih telah menggunakan bot ini, untuk mendukung bot ini kamu dapat membantu dengan berdonasi melalui link berikut:
1. Saweria: https://saweria.co/yogasakti
2. Trakteer: https://trakteer.id/red-emperor 

Donasi akan digunakan untuk pengembangan dan pengoperasian bot ini.

Terimakasih.`
}
