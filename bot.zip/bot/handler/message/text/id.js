exports.textTnC = () => {
    return `
Source code / bot ini merupakan program open-source (gratis) yang ditulis menggunakan Javascript, kamu dapat menggunakan, menyalin, memodifikasi, menggabungkan, menerbitkan, mendistribusikan, mensublisensikan, dan atau menjual salinan dengan tanpa menghapus author utama dari source code / bot ini.

Dengan menggunakan source code / bot ini maka anda setuju dengan Syarat dan Kondisi sebagai berikut:
- Source code / bot tidak menyimpan data anda di server kami.
- Source code / bot tidak bertanggung jawab atas sticker yang anda buat dari bot ini serta video, gambar maupun data lainnya yang anda dapatkan dari Source code / bot ini.
- Source code / bot tidak boleh digunakan untuk layanan yang bertujuan/berkontribusi dalam: 
    • seks / perdagangan manusia
    • perjudian
    • perilaku adiktif yang merugikan 
    • kejahatan
    • kekerasan (kecuali jika diperlukan untuk melindungi keselamatan publik)
    • pembakaran hutan / penggundulan hutan
    • ujaran kebencian atau diskriminasi berdasarkan usia, jenis kelamin, identitas gender, ras, seksualitas, agama, kebangsaan

Source Code BOT : https://github.com/YogaSakti/imageToSticker
NodeJS WhatsApp library: https://github.com/open-wa/wa-automate-nodejs

Best regards, Yoga Sakti.`
}

exports.textMenu = (pushname) => {
    return `Hi, ${pushname}! 👋️ \n\nWelcome To D-Bot!✨\n\nlist menu (command) :\n\n1. #menu / #help : Untuk Tampilkan semua fitur & #ping untuk cek bot aktif\n2. #sticker / #stiker: kirim gambar dengan caption atau balas gambar yang sudah dikirim. ✅ \n3. #sticker / #stiker spasi url gambar (contoh: #stiker https://avatars2.githubusercontent.com/u/24309806) ✅\n4. #ig spasi url videonya : (contoh : #ig https://www.instagram.com/p/B3gqNXwB00pG/)\n 5. #fb spasi url videonya : (contoh: #fb https://www.tiktok.com/@diditx87/video/6854861929)✅\n 6. #twt spasi url videonya (contoh: #twt https://twitter.com/diditx87/status/1289776000474083328)✅\n  7. #tiktok spasi url videonya (contoh: #tiktok https://www.tiktok.com/@diditx87/video/685521...) (update)✅\n8. #corona : Untuk Menampilkan data corona terbaru di Indonesia (updated) ✅\n9. #quotes : Random quotes mbucin ✅\n10. #liriklagu *surat-cinta* : Menampilkan lirik lagu *surat cinta* ✅\n 11. #artinama *roti* : Menampilkan arti nama dari *roti* ✅\n12. #weton 06 08 1995* : Cek weton dan watak (tgl bulan tahun) ✅\n13. #quotemaker *coba-coba-saja rotibakar random* : Tampilkan gambar quotes (pisahkan dengan -) dengan nama *rotibakar* dan gambar tema *random* ✅\n14. #namaninjaku ahmadlemon : Tampilkan nama ninja terkeren dari *ahmad lemon* ✅\n15. #unsplash : Download wallpaper dari unsplash ✅\n16. #kuching : Download gambar kucing random ✅\n17. #anime : Download gambar anime (kadang gambar gak cocok) ✅\n18. #wp nature : Download gambar dari unsplash dengan keyword *nature* ✅\n19. #jodoh *aku kamu* : Ramal jodoh dari nama *aku* & *kamu* ✅\n 20. #yt link youtube : Download video dari youtube ✅\n21. #ytmp3 link youtube : Download music dari youtube dengan format mp3 ✅\n22. #quote2make *quotesmuquotesmu authornya gambare ukurantext* : versi 2 quotesmaker contoh *#quote2make rebahan kuli bangunan 1 25* (update : kalo ngirim html ulangi) ✅\n23. #alay katakatamu : buat ubah text jadi alay kaya *aku* jadi *4kU* ✅\n24. #lasegar : menampilkan gambar yang seger-seger (gambar cuman 19 doang kalo nemu yang cocok diupdate) ✅\n25. #grouplink : menampilkan link dari grup (buat bot ini admin dulu)✅\n26. #wpnime : versi 2 nampilkan walpapper anime/n ✅\n27. #waifu : menampilkan gambar waifu anime/n ✅\n28. #neko : menampilkan gambar anime cosplay kucing ✅\n29. #lolinime : menampilkan gambar anime loli ✅\n30. #meme : menampilkan meme fresh  ✅\n31. #gif/#stikergif/#gifstiker : buat sticker bergerak dari giphy ✅`
            

  /*  `
Hi, ${pushname}! 👋️
Berikut adalah beberapa fitur yang ada pada bot ini!✨

Sticker Creator:
1. *#sticker*
Untuk merubah gambar menjadi sticker. (kirim gambar dengan caption #sticker atau balas gambar yang sudah dikirim dengan #sticker)

1. *#sticker*
Untuk merubah gambar menjadi sticker. (kirim gambar dengan caption #sticker atau balas gambar yang sudah dikirim dengan #sticker)

2. *#sticker* _<Url Gambar>_
Untuk merubah gambar dari url menjadi sticker. 

3. *#gifsticker* _<Giphy URL>_ / *#stickergif* _<Giphy URL>_
Untuk merubah gif menjadi sticker (Giphy Only)

Downloader:
1. *#tiktok* _<tiktol url> _
Untuk mengunduh video dari video tiktok.

2. *#fb* _<post/video url>_
Untuk mengunduh video dari Facebook.

3. *#ig* _<instagram post url>_
Untuk mengunduh photo dan video dari instagram.

4. *#twt* _<twitter post url>_
Untuk mengunduh photo dan video dari Twitter.

Lain-lain:
1. *#resi* _<kurir>_ _<nomer resi>_
Untuk memeriksa status pengiriman barang, daftar kurir: jne, pos, tiki, wahana, jnt, rpx, sap, sicepat, pcp, jet, dse, first, ninja, lion, idl, rex.

2. *#tnc*
Menampilkan Syarat dan Kondisi Bot.

3. *#donasi*
menampilkan informasi donasi.

Hope you have a great day!✨`*/
}

exports.textAdmin = () => {
    return `
⚠ [ *Admin Group Only* ] ⚠ 
Berikut adalah beberapa fitur admin grup yang ada pada bot ini!

1. *#kick* @user
Untuk mengeluarkan member dari grup (bisa lebih dari 1).

2. *#promote* @user
Untuk mempromosikan member menjadi Admin grup.

3. *#demote* @user
Untuk demosikan Admin grup.

4. *#tagall*
Untuk mention semua member grup. (Premium Only)

5. *#del*
Untuk menghapus pesan bot (balas pesan bot dengan #del)`
}

exports.textDonasi = () => {
    return `
Hai, terimakasih telah menggunakan bot ini, untuk mendukung bot ini kamu dapat membantu dengan berdonasi melalui link berikut:
1. Saweria: https://saweria.co/yogasakti
2. Trakteer: https://trakteer.id/red-emperor 

Donasi akan digunakan untuk pengembangan dan pengoperasian bot ini.

Terimakasih.`
}
