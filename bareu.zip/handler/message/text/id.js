exports.textTnC = () => {
    return `
Source code / bot ini merupakan program open-source (gratis) yang ditulis menggunakan Javascript, kamu dapat menggunakan, menyalin, memodifikasi, menggabungkan, menerbitkan, mendistribusikan, mensublisensikan, dan atau menjual salinan dengan tanpa menghapus author utama dari source code / bot ini.

Dengan menggunakan source code / bot ini maka anda setuju dengan Syarat dan Kondisi sebagai berikut:
- Source code / bot tidak menyimpan data anda di server kami.
- Source code / bot tidak bertanggung jawab atas sticker yang anda buat dari bot ini serta video, gambar maupun data lainnya yang anda dapatkan dari Source code / bot ini.
- Source code / bot tidak boleh digunakan untuk layanan yang bertujuan/berkontribusi dalam: 
    • seks / perdagangan manusia
    • perjudian
    • perilaku adiktif yang merugikan 
    • kejahatan
    • kekerasan (kecuali jika diperlukan untuk melindungi keselamatan publik)
    • pembakaran hutan / penggundulan hutan
    • ujaran kebencian atau diskriminasi berdasarkan usia, jenis kelamin, identitas gender, ras, seksualitas, agama, kebangsaan

Source Code BOT : https://github.com/YogaSakti/imageToSticker
NodeJS WhatsApp library: https://github.com/open-wa/wa-automate-nodejs

Best regards, Yoga Sakti.`
}
exports.helpMenu = (pushname) => {
     return `
Hi, ${pushname}! 👋️ 
Welcome To D-Bot!✨

Bot ini gratis untuk anda. Boleh reshare kalo suka.
!!Update & Fix bot sukses!!
Bot Aktif mulai jam 07.00-22.00. kalo gak on jangan di spam.

Untuk list Command :
1. #ping : Untuk Mengecek Bot aktif atau ngaknya
2. #menu : untuk menampilkan command menu simple
3. #menuadmin : Menu khusus untuk admin di dalam grup
4. #fmenu : Untuk melihat deskripsi full dari list #menu
5. #join link_grup : untuk memasukan bot ke dalam grup


DILARANG KERAS UNTUK MENELFON BOT. TELFON = BLOCK!!
     `}
exports.textfMenu = (pushname) => {
    return `
Hi, ${pushname}! 👋️ 
Ini Menunya :

======>New Menu<=======

1. *#tagall* _kata kata mu|_
untuk tag semua anggota didalam grup

2. 

======>Sticker Menu<=======

1. *#sticker*
Untuk merubah gambar menjadi sticker. (kirim gambar dengan caption #sticker atau balas gambar yang sudah dikirim dengan #sticker)

2. *#sticker* _<Url Gambar>_
Untuk merubah gambar dari url menjadi sticker. 

3. *#gifsticker* _<Giphy URL>_ / *#stickergif* _<Giphy URL>_
Untuk merubah gif menjadi sticker (Giphy Only)

======>Sosmed & Youtube<=======

1. *#ig* _<IG URL>_ / *#instagram* _<IG URL>
Untuk Mendownload video atau foto dari IG

2. *#ig2* _<IG URL>_ / *#instagram* _<IG URL>
Versi Ke 2 dari ig downloader

3. *#fb* _<Facebook URL>_ / *#facebook* _<Facebook URL>
Untuk Mendownload video dari Facebook

4. *#twt* _<Twitter URL>_ / *#twitter* _<Twitter URL>
Untuk Mendownload video atau foto dari Twitter

5. *#tiktok* _<Tiktok URL>_
Untuk Mendownload video dari tiktok

6. *#yt* _<Youtube URL>_
Untuk Mendownload video dari youtube

7. *#ytmp3* _<Youtube URL>_
Untuk Mendownload music dari youtube berbentuk mp3

======>Menu Lain<=======

1. *#jodoh* _Namamu Namanya_
Untuk Menampilkan Ramalan jodoh

2. *#corona*
Untuk Menampilkan data corona terbaru di Indonesia

3. *#artinama* _Namamu_
Untuk Menampilkan arti dari Namamu

4. *#liriklagu* _judul-lagu_
Untuk Mencari lirik lagu

5. *#weton* _12 12 2000_
Untuk mengecek weton dan watak dari tanggal kelahiranmu

6. *#alay* _alay+lu_
Untuk mengubah text jadi 4l4y

7. *#namaninjaku* _Namamu_
Untuk Menampilkan arti dari Nama ninjamu

8. *#quotesmaker* _kata-kata author background_
Untuk menampilkan gambar quotes bikinanmu

9. *#quote2make* _kata-kata author background ukurantext_
versi kedua dari #quotesmaker

10. *#cuaca* _kota_
Untuk menampilkan info cuaca kotamu

11. *#resi* _ekpedisi nomer_resi_
menampilkan info dari paket kamu

12. *#tts* _kata terserah kamu_
membuat vn dari kata terserah kamu (teks to speak)

13. *#meme*
menampilkan gambar meme dari reddit

14. *#surah* (coming soon)
menampilkan surah dari alquran


======>Walpapper & Anime<=======

1. *#unsplash* / *#wp*
Menampilkan wallpaper dari unsplash

2. *#neko*
Menampilkan wallpaper dari anime cosplay kucing

3. *#wpnime*
Menampilkan wallpaper anime

4 *#lolinime*
Menampilkan wallpaper dari anime loli

5. *#waifu*
Menampilkan wallpaper waifu di anime

6. *#kuching*
Menampilkan wallpaper kucing

7. *#lasegar*
Menampilkan foto penyegar

    `}
exports.textMenu = (pushname) => {
    return `
Hi, ${pushname}! 👋️ 
======>list command (simple)<======

==> #sticker     ==> #gifsticker
==> #ig          ==> #fb
==> #facebook    ==> #twt
==> #tiktok      ==> #yt
==> #ytmp3       ==> #jodoh
==> #corona      ==> #artinama
==> #liriklagu   ==> #weton
==> #alay        ==> #namaninjaku
==> #quotesmaker ==> #quote2make
==> #cuaca       ==> #unsplash
==> #wp          ==> #neko
==> #wpnime      ==> #lolinime
==> #waifu      ==> #kuching
==> #lasegar
`}

exports.textAdmin = () => {
    return `
⚠ [ *Admin Group Only* ] ⚠ 
Berikut adalah beberapa fitur admin grup yang ada pada bot ini!

1. *#kick* @user
Untuk mengeluarkan member dari grup (bisa lebih dari 1).

2. *#promote* @user
Untuk mempromosikan member menjadi Admin grup.

3. *#demote* @user
Untuk demosikan Admin grup.

4. *#tagall*
Untuk mention semua member grup.

5. *#del*
Untuk menghapus pesan bot (balas pesan bot dengan #del)

6. *#bye*
Untuk mengeluarkan bot dari grup

7. *#linkgrup*
Untuk menampilkan link dari grup

8. *#bc*
Untuk Membroadcast ke anggota grup 
`}

exports.textDonasi = () => {
    return `
Hai, terimakasih telah menggunakan bot ini, untuk mendukung bot ini kamu dapat membantu dengan berdonasi melalui link berikut:
1. Saweria: https://saweria.co/yogasakti
2. Trakteer: https://trakteer.id/red-emperor 

Donasi akan digunakan untuk pengembangan dan pengoperasian bot ini.

Terimakasih.`
}
